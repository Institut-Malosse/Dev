﻿
namespace CalculAge
{
    partial class FrmPrincipale
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.LblPrenom = new System.Windows.Forms.Label();
            this.LblDateNaissance = new System.Windows.Forms.Label();
            this.LblAutreDate = new System.Windows.Forms.Label();
            this.TxtPrenom = new System.Windows.Forms.TextBox();
            this.TxtDateNaissance = new System.Windows.Forms.TextBox();
            this.TxtAutreDate = new System.Windows.Forms.TextBox();
            this.BtnPremierAlgo = new System.Windows.Forms.Button();
            this.LblTitre = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // LblPrenom
            // 
            this.LblPrenom.AutoSize = true;
            this.LblPrenom.Location = new System.Drawing.Point(284, 66);
            this.LblPrenom.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LblPrenom.Name = "LblPrenom";
            this.LblPrenom.Size = new System.Drawing.Size(120, 21);
            this.LblPrenom.TabIndex = 0;
            this.LblPrenom.Text = "Votre prénom :";
            // 
            // LblDateNaissance
            // 
            this.LblDateNaissance.AutoSize = true;
            this.LblDateNaissance.Location = new System.Drawing.Point(213, 103);
            this.LblDateNaissance.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LblDateNaissance.Name = "LblDateNaissance";
            this.LblDateNaissance.Size = new System.Drawing.Size(191, 21);
            this.LblDateNaissance.TabIndex = 0;
            this.LblDateNaissance.Text = "Votre date de naissance :";
            // 
            // LblAutreDate
            // 
            this.LblAutreDate.AutoSize = true;
            this.LblAutreDate.Location = new System.Drawing.Point(32, 140);
            this.LblAutreDate.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LblAutreDate.Name = "LblAutreDate";
            this.LblAutreDate.Size = new System.Drawing.Size(372, 21);
            this.LblAutreDate.TabIndex = 0;
            this.LblAutreDate.Text = "À quelle date voudriez-vous connaitre votre âge ?";
            // 
            // TxtPrenom
            // 
            this.TxtPrenom.Location = new System.Drawing.Point(412, 63);
            this.TxtPrenom.Margin = new System.Windows.Forms.Padding(4);
            this.TxtPrenom.Name = "TxtPrenom";
            this.TxtPrenom.Size = new System.Drawing.Size(127, 29);
            this.TxtPrenom.TabIndex = 1;
            // 
            // TxtDateNaissance
            // 
            this.TxtDateNaissance.Location = new System.Drawing.Point(412, 100);
            this.TxtDateNaissance.Margin = new System.Windows.Forms.Padding(4);
            this.TxtDateNaissance.Name = "TxtDateNaissance";
            this.TxtDateNaissance.Size = new System.Drawing.Size(127, 29);
            this.TxtDateNaissance.TabIndex = 1;
            // 
            // TxtAutreDate
            // 
            this.TxtAutreDate.Location = new System.Drawing.Point(412, 137);
            this.TxtAutreDate.Margin = new System.Windows.Forms.Padding(4);
            this.TxtAutreDate.Name = "TxtAutreDate";
            this.TxtAutreDate.Size = new System.Drawing.Size(127, 29);
            this.TxtAutreDate.TabIndex = 1;
            // 
            // BtnPremierAlgo
            // 
            this.BtnPremierAlgo.Location = new System.Drawing.Point(279, 200);
            this.BtnPremierAlgo.Margin = new System.Windows.Forms.Padding(4);
            this.BtnPremierAlgo.Name = "BtnPremierAlgo";
            this.BtnPremierAlgo.Size = new System.Drawing.Size(260, 74);
            this.BtnPremierAlgo.TabIndex = 2;
            this.BtnPremierAlgo.Text = "Exécuter l\'algorithme !";
            this.BtnPremierAlgo.UseVisualStyleBackColor = true;
            this.BtnPremierAlgo.Click += new System.EventHandler(this.BtnPremierAlgo_Click);
            // 
            // LblTitre
            // 
            this.LblTitre.AutoSize = true;
            this.LblTitre.Font = new System.Drawing.Font("Segoe UI Black", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.LblTitre.ForeColor = System.Drawing.SystemColors.Highlight;
            this.LblTitre.Location = new System.Drawing.Point(13, 9);
            this.LblTitre.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LblTitre.Name = "LblTitre";
            this.LblTitre.Size = new System.Drawing.Size(136, 30);
            this.LblTitre.TabIndex = 3;
            this.LblTitre.Text = "Calcul d\'âge";
            // 
            // FrmPrincipale
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 21F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(552, 287);
            this.Controls.Add(this.LblTitre);
            this.Controls.Add(this.BtnPremierAlgo);
            this.Controls.Add(this.TxtAutreDate);
            this.Controls.Add(this.TxtDateNaissance);
            this.Controls.Add(this.TxtPrenom);
            this.Controls.Add(this.LblAutreDate);
            this.Controls.Add(this.LblDateNaissance);
            this.Controls.Add(this.LblPrenom);
            this.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "FrmPrincipale";
            this.Text = "Calcul d\'âge";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LblPrenom;
        private System.Windows.Forms.Label LblDateNaissance;
        private System.Windows.Forms.Label LblAutreDate;
        private System.Windows.Forms.TextBox TxtPrenom;
        private System.Windows.Forms.TextBox TxtDateNaissance;
        private System.Windows.Forms.TextBox TxtAutreDate;
        private System.Windows.Forms.Button BtnPremierAlgo;
        private System.Windows.Forms.Label LblTitre;
    }
}

