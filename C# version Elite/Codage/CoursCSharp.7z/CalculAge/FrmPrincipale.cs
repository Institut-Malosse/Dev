﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CalculAge
{
    public partial class FrmPrincipale : Form
    {
        public void SaveCode()
        {
            string prénom = TxtPrenom.Text; // On déclare une variable chaine avec le contenu de la boite de texte

            if (string.IsNullOrWhiteSpace(prénom))
            {
                MessageBox.Show("Prénom invalide.");
            }
            else
            {
                if (DateTime.TryParse(TxtDateNaissance.Text, out DateTime dateDeNaissance)
                    && DateTime.TryParse(TxtAutreDate.Text, out DateTime uneAutreDate))
                {
                    string résultat = "(texte vide)"; // On déclare une variable chaine contenant "(texte vide)"

                    if (dateDeNaissance > uneAutreDate) // Si la date de naissance est supérieure à l'autre date
                    {
                        // Oui : la date de naissance EST supérieure à l'autre date !
                        // On concatène une réponse pour dire que la personne n'était pas née
                        résultat = prénom + " n'était même pas né(e) le " + uneAutreDate.ToString() + " !";
                    }
                    else
                    {
                        // Non : la date de naissance N'EST PAS supérieure à l'autre date !
                        for (int i = 0; i < 150; i++) // On démarre une boucle, avec une variable i, de type entier (itérateur)
                        {
                            if (dateDeNaissance.AddYears(i) > uneAutreDate) // Si la date de naissance + i année(s) est STRICTEMENT supérieure à l'autre date
                            {
                                // Oui : la date de naissance + i année(s) EST supérieure ou égale à l'autre date !
                                int age = i - 1; // On calcule l'âge
                                string verbeAvoir = "(avoir)"; // On décide du verbe
                                string verbeEtre = "(être)"; // On décide du verbe
                                if (uneAutreDate < DateTime.Today)
                                {
                                    verbeAvoir = "avait"; // Passé
                                    verbeEtre = "c'était";
                                }
                                else if (uneAutreDate == DateTime.Today)
                                {
                                    verbeAvoir = "a"; // Présent
                                    verbeEtre = "c'est";
                                }
                                else if (uneAutreDate > DateTime.Today)
                                {
                                    verbeAvoir = "aura"; // Futur
                                    verbeEtre = "ça sera";
                                }
                                string pluriel = string.Empty; // On met une chaine vide.
                                if (age > 1)
                                {
                                    pluriel = "s"; // Si l'âge est supérieur à 1, on met un s.
                                }
                                résultat = prénom + " " + verbeAvoir + " " + age.ToString() + " an" + pluriel + " !"; // On construit la phrase avec précision
                                if (dateDeNaissance.Month == uneAutreDate.Month && dateDeNaissance.Day == uneAutreDate.Day)
                                {
                                    résultat = résultat + " Et " + verbeEtre + " pile le jour de son anniversaire !";
                                }
                                break;
                            }
                        }
                    }

                    MessageBox.Show(résultat); // On affiche le résultat de l'algorithme dans une boite de message
                }
                else
                {
                    MessageBox.Show("Date invalide.");
                }
            }
        }

        public FrmPrincipale()
        {
            InitializeComponent();

            TxtPrenom.Text = Environment.UserName;
            TxtAutreDate.Text = DateTime.Today.ToString("dd/MM/yyyy");
        }

        private void BtnPremierAlgo_Click(object sender, EventArgs e)
        {
            string résultat = "(texte vide)"; // On déclare une variable chaine contenant "(texte vide)"
            string prénom = TxtPrenom.Text; // On déclare une variable chaine contenant "Jean-Michel"
            
            if (prénom == "")
            {
                MessageBox.Show("Veuillez indiquer un prénom");
                return;
            }
            DateTime uneAutreDate = new DateTime(2020, 1, 1);
            if (!DateTime.TryParse(TxtDateNaissance.Text, out DateTime dateDeNaissance)
                || !DateTime.TryParse(TxtAutreDate.Text, out uneAutreDate))
            {
                MessageBox.Show("Veuillez indiquer une date valide");
                return;
            }


            if (dateDeNaissance > uneAutreDate) // Si la date de naissance est supérieure à l'autre date
            {
                // Oui : la date de naissance EST supérieure à l'autre date !
                // On concatène une réponse pour dire que la personne n'était pas née
                résultat = prénom + " n'était même pas né(e) le " + uneAutreDate.ToString() + " !";
            }
            else
            {
                // Non : la date de naissance N'EST PAS supérieure à l'autre date !
                for (int i = 0; i < 99; i++) // On démarre une boucle, avec une variable i, de type entier (itérateur)
                {
                    if (dateDeNaissance.AddYears(i) >= uneAutreDate) // Si la date de naissance + i année(s) est supérieure ou égale à l'autre date
                    {
                        // Oui : la date de naissance + i année(s) EST supérieure ou égale à l'autre date !
                        string verbeAvoir = "avait";
                        if (uneAutreDate == DateTime.Today)
                        {
                            verbeAvoir = "a";
                        }
                        else if (uneAutreDate > DateTime.Today)
                        {
                            verbeAvoir = "aura";
                        }
                        
                        résultat = prénom + " " + verbeAvoir + " " + i.ToString() + " an(s) !"; // On indique l'age calculé (qui vaut la valeur de i)
                        if (dateDeNaissance.Month == uneAutreDate.Month && dateDeNaissance.Day == uneAutreDate.Day)
                        {
                            résultat = résultat + " Et c'était pile le jour de son anniversaire !";
                        }
                        break;
                    }
                }
            }

            MessageBox.Show(résultat); // On affiche le résultat de l'algorithme dans une boite de message
        }
    }
}
