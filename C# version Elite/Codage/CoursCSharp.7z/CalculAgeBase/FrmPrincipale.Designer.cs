﻿
namespace CalculAgeBase
{
    partial class FrmPrincipale
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.BtnPremierAlgo = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // BtnPremierAlgo
            // 
            this.BtnPremierAlgo.Location = new System.Drawing.Point(126, 113);
            this.BtnPremierAlgo.Name = "BtnPremierAlgo";
            this.BtnPremierAlgo.Size = new System.Drawing.Size(131, 66);
            this.BtnPremierAlgo.TabIndex = 0;
            this.BtnPremierAlgo.Text = "Premier Algo";
            this.BtnPremierAlgo.UseVisualStyleBackColor = true;
            this.BtnPremierAlgo.Click += new System.EventHandler(this.BtnPremierAlgo_Click);
            // 
            // FrmPrincipale
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(387, 281);
            this.Controls.Add(this.BtnPremierAlgo);
            this.Name = "FrmPrincipale";
            this.Text = "Premier Algo";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button BtnPremierAlgo;
    }
}

