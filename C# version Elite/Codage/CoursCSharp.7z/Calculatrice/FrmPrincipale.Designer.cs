﻿
namespace Calculatrice
{
    partial class FrmPrincipale
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.LblTitre = new System.Windows.Forms.Label();
            this.TxtPremierTerme = new System.Windows.Forms.TextBox();
            this.TxtOperateur = new System.Windows.Forms.TextBox();
            this.TxtSecondTerme = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.BtnLancer = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.CbArrondir = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // LblTitre
            // 
            this.LblTitre.AutoSize = true;
            this.LblTitre.Font = new System.Drawing.Font("Segoe UI Black", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.LblTitre.ForeColor = System.Drawing.SystemColors.Highlight;
            this.LblTitre.Location = new System.Drawing.Point(13, 9);
            this.LblTitre.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LblTitre.Name = "LblTitre";
            this.LblTitre.Size = new System.Drawing.Size(131, 30);
            this.LblTitre.TabIndex = 4;
            this.LblTitre.Text = "Calculatrice";
            // 
            // TxtPremierTerme
            // 
            this.TxtPremierTerme.Location = new System.Drawing.Point(13, 83);
            this.TxtPremierTerme.Name = "TxtPremierTerme";
            this.TxtPremierTerme.Size = new System.Drawing.Size(122, 29);
            this.TxtPremierTerme.TabIndex = 5;
            this.TxtPremierTerme.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // TxtOperateur
            // 
            this.TxtOperateur.Location = new System.Drawing.Point(141, 83);
            this.TxtOperateur.Name = "TxtOperateur";
            this.TxtOperateur.Size = new System.Drawing.Size(89, 29);
            this.TxtOperateur.TabIndex = 5;
            this.TxtOperateur.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // TxtSecondTerme
            // 
            this.TxtSecondTerme.Location = new System.Drawing.Point(236, 83);
            this.TxtSecondTerme.Name = "TxtSecondTerme";
            this.TxtSecondTerme.Size = new System.Drawing.Size(122, 29);
            this.TxtSecondTerme.TabIndex = 5;
            this.TxtSecondTerme.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 59);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(115, 21);
            this.label1.TabIndex = 6;
            this.label1.Text = "Premier terme";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(141, 59);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(85, 21);
            this.label2.TabIndex = 6;
            this.label2.Text = "Opérateur";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(236, 59);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(113, 21);
            this.label3.TabIndex = 6;
            this.label3.Text = "Second terme";
            // 
            // BtnLancer
            // 
            this.BtnLancer.Location = new System.Drawing.Point(107, 197);
            this.BtnLancer.Margin = new System.Windows.Forms.Padding(4);
            this.BtnLancer.Name = "BtnLancer";
            this.BtnLancer.Size = new System.Drawing.Size(260, 74);
            this.BtnLancer.TabIndex = 7;
            this.BtnLancer.Text = "Exécuter l\'algorithme !";
            this.BtnLancer.UseVisualStyleBackColor = true;
            this.BtnLancer.Click += new System.EventHandler(this.BtnLancer_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(151, 115);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(71, 21);
            this.label4.TabIndex = 6;
            this.label4.Text = "+ - x / %";
            // 
            // CbArrondir
            // 
            this.CbArrondir.AutoSize = true;
            this.CbArrondir.Location = new System.Drawing.Point(277, 165);
            this.CbArrondir.Name = "CbArrondir";
            this.CbArrondir.Size = new System.Drawing.Size(91, 25);
            this.CbArrondir.TabIndex = 8;
            this.CbArrondir.Text = "Arrondir";
            this.CbArrondir.UseVisualStyleBackColor = true;
            // 
            // FrmPrincipale
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 21F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(380, 286);
            this.Controls.Add(this.CbArrondir);
            this.Controls.Add(this.BtnLancer);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.TxtOperateur);
            this.Controls.Add(this.TxtSecondTerme);
            this.Controls.Add(this.TxtPremierTerme);
            this.Controls.Add(this.LblTitre);
            this.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "FrmPrincipale";
            this.Text = "Calculatrice";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LblTitre;
        private System.Windows.Forms.TextBox TxtPremierTerme;
        private System.Windows.Forms.TextBox TxtOperateur;
        private System.Windows.Forms.TextBox TxtSecondTerme;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button BtnLancer;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.CheckBox CbArrondir;
    }
}

