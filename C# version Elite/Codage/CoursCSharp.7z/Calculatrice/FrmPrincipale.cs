﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculatrice
{
    public partial class FrmPrincipale : Form
    {
        public FrmPrincipale()
        {
            InitializeComponent();
        }

        private void BtnLancer_Click(object sender, EventArgs e)
        {
            // Contrôles de saisie
            if (!decimal.TryParse(TxtPremierTerme.Text, out decimal premierTerme))
            {
                MessageBox.Show("Le premier terme doit être un nombre décimal.");
                return;
            }
            string operateur = TxtOperateur.Text;
            if (operateur != "+" && operateur != "-" && operateur != "x" && operateur != "/" && operateur != "%")
            {
                MessageBox.Show("L'opérateur doit être + - x / ou %.");
                return;
            }
            if (!decimal.TryParse(TxtSecondTerme.Text, out decimal secondTerme))
            {
                MessageBox.Show("Le second terme doit être un nombre décimal.");
                return;
            }
            if (operateur == "/" && secondTerme == 0)
            {
                MessageBox.Show("On ne peut pas diviser par zéro");
                return;
            }

            // Calculs
            decimal resultat = 0;
            if (operateur == "+")
            {
                resultat = premierTerme + secondTerme;
            }
            if (operateur == "-")
            {
                resultat = premierTerme - secondTerme;
            }
            if (operateur == "x")
            {
                resultat = premierTerme * secondTerme;
            }
            if (operateur == "/")
            {
                resultat = premierTerme / secondTerme;
            }
            if (operateur == "%")
            {
                resultat = premierTerme % secondTerme;
            }
            if (CbArrondir.Checked)
            {
                resultat = Math.Round(resultat, 2);
            }

            // Affichage du résultat
            string reponse = "Le resultat de l'opération est : " + resultat.ToString();
            MessageBox.Show(reponse);
        }
    }
}
