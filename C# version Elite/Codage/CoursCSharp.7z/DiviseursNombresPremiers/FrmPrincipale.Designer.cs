﻿
namespace DiviseursNombresPremiers
{
    partial class FrmPrincipale
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.LblTitre = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.LblResultatDiviseurs = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.TxtNombreEntierPositif = new System.Windows.Forms.TextBox();
            this.BtnRechercherDiviseurs = new System.Windows.Forms.Button();
            this.RbtOui = new System.Windows.Forms.RadioButton();
            this.RbtNon = new System.Windows.Forms.RadioButton();
            this.SuspendLayout();
            // 
            // LblTitre
            // 
            this.LblTitre.AutoSize = true;
            this.LblTitre.Font = new System.Drawing.Font("Segoe UI Black", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.LblTitre.ForeColor = System.Drawing.SystemColors.Highlight;
            this.LblTitre.Location = new System.Drawing.Point(14, 9);
            this.LblTitre.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.LblTitre.Name = "LblTitre";
            this.LblTitre.Size = new System.Drawing.Size(327, 30);
            this.LblTitre.TabIndex = 8;
            this.LblTitre.Text = "Diviseurs et nombres premiers";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(14, 55);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(262, 21);
            this.label1.TabIndex = 9;
            this.label1.Text = "Saisissez un nombre entier positif :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(14, 128);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(142, 21);
            this.label2.TabIndex = 10;
            this.label2.Text = "Diviseurs trouvés :";
            // 
            // LblResultatDiviseurs
            // 
            this.LblResultatDiviseurs.AutoSize = true;
            this.LblResultatDiviseurs.Location = new System.Drawing.Point(162, 128);
            this.LblResultatDiviseurs.Name = "LblResultatDiviseurs";
            this.LblResultatDiviseurs.Size = new System.Drawing.Size(40, 21);
            this.LblResultatDiviseurs.TabIndex = 11;
            this.LblResultatDiviseurs.Text = "N/A";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(14, 163);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(185, 21);
            this.label4.TabIndex = 12;
            this.label4.Text = "Le nombre est premier :";
            // 
            // TxtNombreEntierPositif
            // 
            this.TxtNombreEntierPositif.Location = new System.Drawing.Point(282, 52);
            this.TxtNombreEntierPositif.Name = "TxtNombreEntierPositif";
            this.TxtNombreEntierPositif.Size = new System.Drawing.Size(122, 29);
            this.TxtNombreEntierPositif.TabIndex = 13;
            this.TxtNombreEntierPositif.TextChanged += new System.EventHandler(this.TxtNombreEntierPositif_TextChanged);
            // 
            // BtnRechercherDiviseurs
            // 
            this.BtnRechercherDiviseurs.Enabled = false;
            this.BtnRechercherDiviseurs.Location = new System.Drawing.Point(12, 87);
            this.BtnRechercherDiviseurs.Name = "BtnRechercherDiviseurs";
            this.BtnRechercherDiviseurs.Size = new System.Drawing.Size(392, 29);
            this.BtnRechercherDiviseurs.TabIndex = 14;
            this.BtnRechercherDiviseurs.Text = "Rechercher les diviseurs";
            this.BtnRechercherDiviseurs.UseVisualStyleBackColor = true;
            this.BtnRechercherDiviseurs.Click += new System.EventHandler(this.BtnRechercherDiviseurs_Click);
            // 
            // RbtOui
            // 
            this.RbtOui.AutoSize = true;
            this.RbtOui.Location = new System.Drawing.Point(205, 161);
            this.RbtOui.Name = "RbtOui";
            this.RbtOui.Size = new System.Drawing.Size(53, 25);
            this.RbtOui.TabIndex = 15;
            this.RbtOui.TabStop = true;
            this.RbtOui.Text = "Oui";
            this.RbtOui.UseVisualStyleBackColor = true;
            // 
            // RbtNon
            // 
            this.RbtNon.AutoSize = true;
            this.RbtNon.Location = new System.Drawing.Point(264, 161);
            this.RbtNon.Name = "RbtNon";
            this.RbtNon.Size = new System.Drawing.Size(59, 25);
            this.RbtNon.TabIndex = 16;
            this.RbtNon.TabStop = true;
            this.RbtNon.Text = "Non";
            this.RbtNon.UseVisualStyleBackColor = true;
            // 
            // FrmPrincipale
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 21F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(416, 202);
            this.Controls.Add(this.RbtNon);
            this.Controls.Add(this.RbtOui);
            this.Controls.Add(this.BtnRechercherDiviseurs);
            this.Controls.Add(this.TxtNombreEntierPositif);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.LblResultatDiviseurs);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.LblTitre);
            this.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "FrmPrincipale";
            this.Text = "Diviseurs et nombres premiers";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LblTitre;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label LblResultatDiviseurs;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox TxtNombreEntierPositif;
        private System.Windows.Forms.Button BtnRechercherDiviseurs;
        private System.Windows.Forms.RadioButton RbtOui;
        private System.Windows.Forms.RadioButton RbtNon;
    }
}

