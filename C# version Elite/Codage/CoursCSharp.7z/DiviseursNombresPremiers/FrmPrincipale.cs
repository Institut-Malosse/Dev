﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DiviseursNombresPremiers
{
    public partial class FrmPrincipale : Form
    {
        public FrmPrincipale()
        {
            InitializeComponent();
        }

        private void BtnRechercherDiviseurs_Click(object sender, EventArgs e)
        {
            // D'abord : on initialise l'interface :
            LblResultatDiviseurs.Text = string.Empty;
            RbtOui.Checked = false;
            RbtNon.Checked = false;

            // Ensuite, on fait des contrôles de saisie :
            if (!int.TryParse(TxtNombreEntierPositif.Text, out int nombreEntier))
            {
                MessageBox.Show("Il faut écrire une nombre entier");
                return;
            }
            if (nombreEntier <= 0)
            {
                MessageBox.Show("Il faut écrire une nombre entier positif");
                return;
            }

            // Ensuite, on applique l'algorithme de recherche de diviseurs
            int nombreDiviseurs = 0;
            for (int i = 0; i < nombreEntier; i++)
            {
                int diviseur = i + 1;
                if (nombreEntier % diviseur == 0) // Le modulo calcule le reste de la division. Par exemple : 14 Modulo 4 = 2
                {
                    nombreDiviseurs++; // Equivaut à : nombreDiviseurs = nombreDiviseurs + 1;
                    LblResultatDiviseurs.Text = LblResultatDiviseurs.Text + diviseur + ", "; // On affiche les diviseurs au fur et à mesure
                }
            }

            // Une fois le nombre total de diviseur trouvé, on indique si le nombre est premier ou pas
            if (nombreDiviseurs > 2)
            {
                RbtNon.Checked = true;
            }
            else
            {
                RbtOui.Checked = true;
            }
        }

        private void TxtNombreEntierPositif_TextChanged(object sender, EventArgs e)
        {
            //if (int.TryParse(TxtNombreEntierPositif.Text, out int nombre) && nombre > 0)
            //{
            //    BtnRechercherDiviseurs.Enabled = true;
            //}
            //else
            //{
            //    BtnRechercherDiviseurs.Enabled = false;
            //}
        }
    }
}
