﻿
namespace EditeurDeTexte
{
    partial class FrmPrincipale
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.LblTitre = new System.Windows.Forms.Label();
            this.TxtFichierDeTravail = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.BtnParcourir = new System.Windows.Forms.Button();
            this.BtnChargerContenu = new System.Windows.Forms.Button();
            this.TxtContenu = new System.Windows.Forms.TextBox();
            this.BtnEnregistrerContenu = new System.Windows.Forms.Button();
            this.BtnFaireUneSauvegarde = new System.Windows.Forms.Button();
            this.BtnSupprimerRepertoireSauvegarde = new System.Windows.Forms.Button();
            this.BtnOuvrirRepertoireSauvegarde = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // LblTitre
            // 
            this.LblTitre.AutoSize = true;
            this.LblTitre.Font = new System.Drawing.Font("Segoe UI Black", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.LblTitre.ForeColor = System.Drawing.SystemColors.Highlight;
            this.LblTitre.Location = new System.Drawing.Point(13, 9);
            this.LblTitre.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LblTitre.Name = "LblTitre";
            this.LblTitre.Size = new System.Drawing.Size(179, 30);
            this.LblTitre.TabIndex = 14;
            this.LblTitre.Text = "Editeur de texte";
            // 
            // TxtFichierDeTravail
            // 
            this.TxtFichierDeTravail.Location = new System.Drawing.Point(13, 69);
            this.TxtFichierDeTravail.Name = "TxtFichierDeTravail";
            this.TxtFichierDeTravail.Size = new System.Drawing.Size(475, 29);
            this.TxtFichierDeTravail.TabIndex = 15;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 45);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(137, 21);
            this.label1.TabIndex = 16;
            this.label1.Text = "Fichier de travail :";
            // 
            // BtnParcourir
            // 
            this.BtnParcourir.AutoSize = true;
            this.BtnParcourir.Location = new System.Drawing.Point(494, 67);
            this.BtnParcourir.Name = "BtnParcourir";
            this.BtnParcourir.Size = new System.Drawing.Size(97, 31);
            this.BtnParcourir.TabIndex = 17;
            this.BtnParcourir.Text = "Parcourir...";
            this.BtnParcourir.UseVisualStyleBackColor = true;
            this.BtnParcourir.Click += new System.EventHandler(this.BtnParcourir_Click);
            // 
            // BtnChargerContenu
            // 
            this.BtnChargerContenu.AutoSize = true;
            this.BtnChargerContenu.Location = new System.Drawing.Point(190, 114);
            this.BtnChargerContenu.Name = "BtnChargerContenu";
            this.BtnChargerContenu.Size = new System.Drawing.Size(232, 31);
            this.BtnChargerContenu.TabIndex = 17;
            this.BtnChargerContenu.Text = "Charger le contenu du fichier";
            this.BtnChargerContenu.UseVisualStyleBackColor = true;
            this.BtnChargerContenu.Click += new System.EventHandler(this.BtnChargerContenu_Click);
            // 
            // TxtContenu
            // 
            this.TxtContenu.Location = new System.Drawing.Point(13, 163);
            this.TxtContenu.Multiline = true;
            this.TxtContenu.Name = "TxtContenu";
            this.TxtContenu.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.TxtContenu.Size = new System.Drawing.Size(578, 174);
            this.TxtContenu.TabIndex = 18;
            // 
            // BtnEnregistrerContenu
            // 
            this.BtnEnregistrerContenu.AutoSize = true;
            this.BtnEnregistrerContenu.Location = new System.Drawing.Point(190, 343);
            this.BtnEnregistrerContenu.Name = "BtnEnregistrerContenu";
            this.BtnEnregistrerContenu.Size = new System.Drawing.Size(232, 31);
            this.BtnEnregistrerContenu.TabIndex = 17;
            this.BtnEnregistrerContenu.Text = "Enregistrer le contenu";
            this.BtnEnregistrerContenu.UseVisualStyleBackColor = true;
            this.BtnEnregistrerContenu.Click += new System.EventHandler(this.BtnEnregistrerContenu_Click);
            // 
            // BtnFaireUneSauvegarde
            // 
            this.BtnFaireUneSauvegarde.AutoSize = true;
            this.BtnFaireUneSauvegarde.Location = new System.Drawing.Point(68, 411);
            this.BtnFaireUneSauvegarde.Name = "BtnFaireUneSauvegarde";
            this.BtnFaireUneSauvegarde.Size = new System.Drawing.Size(473, 31);
            this.BtnFaireUneSauvegarde.TabIndex = 17;
            this.BtnFaireUneSauvegarde.Text = "Faire une sauvegarde du fichier de travail dans un sous-dossier";
            this.BtnFaireUneSauvegarde.UseVisualStyleBackColor = true;
            this.BtnFaireUneSauvegarde.Click += new System.EventHandler(this.BtnFaireUneSauvegarde_Click);
            // 
            // BtnSupprimerRepertoireSauvegarde
            // 
            this.BtnSupprimerRepertoireSauvegarde.AutoSize = true;
            this.BtnSupprimerRepertoireSauvegarde.Location = new System.Drawing.Point(12, 448);
            this.BtnSupprimerRepertoireSauvegarde.Name = "BtnSupprimerRepertoireSauvegarde";
            this.BtnSupprimerRepertoireSauvegarde.Size = new System.Drawing.Size(304, 31);
            this.BtnSupprimerRepertoireSauvegarde.TabIndex = 17;
            this.BtnSupprimerRepertoireSauvegarde.Text = "Supprimer le répertoire de sauvegarde";
            this.BtnSupprimerRepertoireSauvegarde.UseVisualStyleBackColor = true;
            this.BtnSupprimerRepertoireSauvegarde.Click += new System.EventHandler(this.BtnSupprimerRepertoireSauvegarde_Click);
            // 
            // BtnOuvrirRepertoireSauvegarde
            // 
            this.BtnOuvrirRepertoireSauvegarde.AutoSize = true;
            this.BtnOuvrirRepertoireSauvegarde.Location = new System.Drawing.Point(322, 448);
            this.BtnOuvrirRepertoireSauvegarde.Name = "BtnOuvrirRepertoireSauvegarde";
            this.BtnOuvrirRepertoireSauvegarde.Size = new System.Drawing.Size(272, 31);
            this.BtnOuvrirRepertoireSauvegarde.TabIndex = 17;
            this.BtnOuvrirRepertoireSauvegarde.Text = "Ouvrir le répertoire de sauvegarde";
            this.BtnOuvrirRepertoireSauvegarde.UseVisualStyleBackColor = true;
            this.BtnOuvrirRepertoireSauvegarde.Click += new System.EventHandler(this.BtnOuvrirRepertoireSauvegarde_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 21F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(603, 491);
            this.Controls.Add(this.TxtContenu);
            this.Controls.Add(this.BtnFaireUneSauvegarde);
            this.Controls.Add(this.BtnOuvrirRepertoireSauvegarde);
            this.Controls.Add(this.BtnSupprimerRepertoireSauvegarde);
            this.Controls.Add(this.BtnEnregistrerContenu);
            this.Controls.Add(this.BtnChargerContenu);
            this.Controls.Add(this.BtnParcourir);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.TxtFichierDeTravail);
            this.Controls.Add(this.LblTitre);
            this.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Form1";
            this.Text = "Editeur de texte";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LblTitre;
        private System.Windows.Forms.TextBox TxtFichierDeTravail;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button BtnParcourir;
        private System.Windows.Forms.Button BtnChargerContenu;
        private System.Windows.Forms.TextBox TxtContenu;
        private System.Windows.Forms.Button BtnEnregistrerContenu;
        private System.Windows.Forms.Button BtnFaireUneSauvegarde;
        private System.Windows.Forms.Button BtnSupprimerRepertoireSauvegarde;
        private System.Windows.Forms.Button BtnOuvrirRepertoireSauvegarde;
    }
}

