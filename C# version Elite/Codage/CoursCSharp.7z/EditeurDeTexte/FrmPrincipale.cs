﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EditeurDeTexte
{
    public partial class FrmPrincipale : Form
    {
        public FrmPrincipale()
        {
            InitializeComponent();
        }

        private void BtnParcourir_Click(object sender, EventArgs e)
        {
            OpenFileDialog fenetreFichier = new OpenFileDialog();
            fenetreFichier.CheckFileExists = false;
            if (fenetreFichier.ShowDialog() == DialogResult.OK)
            {
                TxtFichierDeTravail.Text = fenetreFichier.FileName;
            }
        }

        private void BtnChargerContenu_Click(object sender, EventArgs e)
        {
            if (File.Exists(TxtFichierDeTravail.Text))
            {
                TxtContenu.Text = File.ReadAllText(TxtFichierDeTravail.Text);
            }
        }

        private void BtnEnregistrerContenu_Click(object sender, EventArgs e)
        {
            File.WriteAllText(TxtFichierDeTravail.Text, TxtContenu.Text);
        }

        private void BtnFaireUneSauvegarde_Click(object sender, EventArgs e)
        {
            if (File.Exists(TxtFichierDeTravail.Text))
            {
                string emplacementDuFichier = Path.GetDirectoryName(TxtFichierDeTravail.Text);
                string nomDuFichier = Path.GetFileName(TxtFichierDeTravail.Text);
                string dossierDeSauvegarde = Path.Combine(emplacementDuFichier, "Sauvegarde");
                string fichierSauvegardé = Path.Combine(dossierDeSauvegarde, nomDuFichier + DateTime.Now.ToString("yyyy.MM.dd.hh.mm.ss") + ".bak");
                if (!Directory.Exists(dossierDeSauvegarde))
                {
                    Directory.CreateDirectory(dossierDeSauvegarde);
                }
                File.Copy(TxtFichierDeTravail.Text, fichierSauvegardé);
            }
        }

        private void BtnSupprimerRepertoireSauvegarde_Click(object sender, EventArgs e)
        {
            string emplacementDuFichier = Path.GetDirectoryName(TxtFichierDeTravail.Text);
            string dossierDeSauvegarde = Path.Combine(emplacementDuFichier, "Sauvegarde");
            if (Directory.Exists(dossierDeSauvegarde))
            {
                if (MessageBox.Show("Êtes-vous sûr de vouloir supprimer le dossier des sauvegardes ?",
                    "Êtes-vous sûr ?", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    Directory.Delete(dossierDeSauvegarde, true);
                }
            }
        }

        private void BtnOuvrirRepertoireSauvegarde_Click(object sender, EventArgs e)
        {
            string emplacementDuFichier = Path.GetDirectoryName(TxtFichierDeTravail.Text);
            string dossierDeSauvegarde = Path.Combine(emplacementDuFichier, "Sauvegarde");
            Process.Start("explorer", dossierDeSauvegarde);
        }
    }
}
