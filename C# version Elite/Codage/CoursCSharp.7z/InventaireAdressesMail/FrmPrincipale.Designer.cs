﻿
namespace InventaireAdressesMail
{
    partial class FrmPrincipale
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.LblTitre = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.TxtAdresseMail = new System.Windows.Forms.TextBox();
            this.CbInterdireDoublons = new System.Windows.Forms.CheckBox();
            this.BtnAjouterMail = new System.Windows.Forms.Button();
            this.TxtTrouverAdressesLesPlusCourtes = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.TxtAdresseTerminantParFr = new System.Windows.Forms.Button();
            this.TxtAdresseTerminantParCom = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.TxtRechercheDomaine = new System.Windows.Forms.TextBox();
            this.BtnRechercheDomaine = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // LblTitre
            // 
            this.LblTitre.AutoSize = true;
            this.LblTitre.Font = new System.Drawing.Font("Segoe UI Black", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.LblTitre.ForeColor = System.Drawing.SystemColors.Highlight;
            this.LblTitre.Location = new System.Drawing.Point(13, 9);
            this.LblTitre.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LblTitre.Name = "LblTitre";
            this.LblTitre.Size = new System.Drawing.Size(293, 30);
            this.LblTitre.TabIndex = 13;
            this.LblTitre.Text = "Inventaire d\'adresse e-mail";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(34, 49);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(220, 21);
            this.label1.TabIndex = 14;
            this.label1.Text = "Saisissez une adresse e-mail :";
            // 
            // TxtAdresseMail
            // 
            this.TxtAdresseMail.CharacterCasing = System.Windows.Forms.CharacterCasing.Lower;
            this.TxtAdresseMail.Location = new System.Drawing.Point(34, 73);
            this.TxtAdresseMail.Name = "TxtAdresseMail";
            this.TxtAdresseMail.Size = new System.Drawing.Size(308, 29);
            this.TxtAdresseMail.TabIndex = 15;
            this.TxtAdresseMail.TextChanged += new System.EventHandler(this.TxtAdresseMail_TextChanged);
            // 
            // CbInterdireDoublons
            // 
            this.CbInterdireDoublons.AutoSize = true;
            this.CbInterdireDoublons.Location = new System.Drawing.Point(357, 48);
            this.CbInterdireDoublons.Name = "CbInterdireDoublons";
            this.CbInterdireDoublons.Size = new System.Drawing.Size(190, 25);
            this.CbInterdireDoublons.TabIndex = 16;
            this.CbInterdireDoublons.Text = "Interdire les doublons";
            this.CbInterdireDoublons.UseVisualStyleBackColor = true;
            // 
            // BtnAjouterMail
            // 
            this.BtnAjouterMail.AutoSize = true;
            this.BtnAjouterMail.Location = new System.Drawing.Point(408, 73);
            this.BtnAjouterMail.Name = "BtnAjouterMail";
            this.BtnAjouterMail.Size = new System.Drawing.Size(75, 31);
            this.BtnAjouterMail.TabIndex = 17;
            this.BtnAjouterMail.Text = "Ajouter";
            this.BtnAjouterMail.UseVisualStyleBackColor = true;
            this.BtnAjouterMail.Click += new System.EventHandler(this.BtnAjouterMail_Click);
            // 
            // TxtTrouverAdressesLesPlusCourtes
            // 
            this.TxtTrouverAdressesLesPlusCourtes.AutoSize = true;
            this.TxtTrouverAdressesLesPlusCourtes.Location = new System.Drawing.Point(90, 133);
            this.TxtTrouverAdressesLesPlusCourtes.Name = "TxtTrouverAdressesLesPlusCourtes";
            this.TxtTrouverAdressesLesPlusCourtes.Size = new System.Drawing.Size(372, 31);
            this.TxtTrouverAdressesLesPlusCourtes.TabIndex = 18;
            this.TxtTrouverAdressesLesPlusCourtes.Text = "Trouver la ou les adresses e-mail les plus courtes";
            this.TxtTrouverAdressesLesPlusCourtes.UseVisualStyleBackColor = true;
            this.TxtTrouverAdressesLesPlusCourtes.Click += new System.EventHandler(this.TxtTrouverAdressesLesPlusCourtes_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(34, 199);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(349, 21);
            this.label2.TabIndex = 19;
            this.label2.Text = "Compter les adresses e-mail se terminant par...";
            // 
            // TxtAdresseTerminantParFr
            // 
            this.TxtAdresseTerminantParFr.AutoSize = true;
            this.TxtAdresseTerminantParFr.Location = new System.Drawing.Point(385, 194);
            this.TxtAdresseTerminantParFr.Name = "TxtAdresseTerminantParFr";
            this.TxtAdresseTerminantParFr.Size = new System.Drawing.Size(36, 31);
            this.TxtAdresseTerminantParFr.TabIndex = 20;
            this.TxtAdresseTerminantParFr.Text = ".fr";
            this.TxtAdresseTerminantParFr.UseVisualStyleBackColor = true;
            this.TxtAdresseTerminantParFr.Click += new System.EventHandler(this.TxtAdresseTerminantParFr_Click);
            // 
            // TxtAdresseTerminantParCom
            // 
            this.TxtAdresseTerminantParCom.AutoSize = true;
            this.TxtAdresseTerminantParCom.Location = new System.Drawing.Point(427, 194);
            this.TxtAdresseTerminantParCom.Name = "TxtAdresseTerminantParCom";
            this.TxtAdresseTerminantParCom.Size = new System.Drawing.Size(56, 31);
            this.TxtAdresseTerminantParCom.TabIndex = 21;
            this.TxtAdresseTerminantParCom.Text = ".com";
            this.TxtAdresseTerminantParCom.UseVisualStyleBackColor = true;
            this.TxtAdresseTerminantParCom.Click += new System.EventHandler(this.TxtAdresseTerminantParCom_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(34, 264);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(428, 21);
            this.label3.TabIndex = 22;
            this.label3.Text = "Trouver les adresses e-mail dont le nom de domaine est...";
            // 
            // TxtRechercheDomaine
            // 
            this.TxtRechercheDomaine.Location = new System.Drawing.Point(154, 290);
            this.TxtRechercheDomaine.Name = "TxtRechercheDomaine";
            this.TxtRechercheDomaine.Size = new System.Drawing.Size(152, 29);
            this.TxtRechercheDomaine.TabIndex = 23;
            // 
            // BtnRechercheDomaine
            // 
            this.BtnRechercheDomaine.AutoSize = true;
            this.BtnRechercheDomaine.Location = new System.Drawing.Point(312, 288);
            this.BtnRechercheDomaine.Name = "BtnRechercheDomaine";
            this.BtnRechercheDomaine.Size = new System.Drawing.Size(50, 31);
            this.BtnRechercheDomaine.TabIndex = 24;
            this.BtnRechercheDomaine.Text = "Go !";
            this.BtnRechercheDomaine.UseVisualStyleBackColor = true;
            this.BtnRechercheDomaine.Click += new System.EventHandler(this.BtnRechercheDomaine_Click);
            // 
            // FrmPrincipale
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 21F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(554, 341);
            this.Controls.Add(this.BtnRechercheDomaine);
            this.Controls.Add(this.TxtRechercheDomaine);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.TxtAdresseTerminantParCom);
            this.Controls.Add(this.TxtAdresseTerminantParFr);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.TxtTrouverAdressesLesPlusCourtes);
            this.Controls.Add(this.BtnAjouterMail);
            this.Controls.Add(this.CbInterdireDoublons);
            this.Controls.Add(this.TxtAdresseMail);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.LblTitre);
            this.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "FrmPrincipale";
            this.Text = "Inventaire d\'adresse e-mail";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LblTitre;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox TxtAdresseMail;
        private System.Windows.Forms.CheckBox CbInterdireDoublons;
        private System.Windows.Forms.Button BtnAjouterMail;
        private System.Windows.Forms.Button TxtTrouverAdressesLesPlusCourtes;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button TxtAdresseTerminantParFr;
        private System.Windows.Forms.Button TxtAdresseTerminantParCom;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox TxtRechercheDomaine;
        private System.Windows.Forms.Button BtnRechercheDomaine;
    }
}

