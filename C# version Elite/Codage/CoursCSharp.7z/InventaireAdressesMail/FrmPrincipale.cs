﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace InventaireAdressesMail
{
    public partial class FrmPrincipale : Form
    {
        List<string> adressesMails = new List<string>();

        public FrmPrincipale()
        {
            InitializeComponent();
        }

        private void TxtAdresseMail_TextChanged(object sender, EventArgs e)
        {
            // Plusieurs approches possibles pour valider une adresse e-mail (à peu près) :
            // if (TxtAdresseMail.Text.Contains("@") && TxtAdresseMail.Text.Contains("."))
            // if (new EmailAddressAttribute().IsValid(TxtAdresseMail.Text))      
            if (Regex.IsMatch(TxtAdresseMail.Text, @"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$"))
            {
                BtnAjouterMail.Enabled = true;
            }
            else
            {
                BtnAjouterMail.Enabled = false;
            }
        }

        private void BtnAjouterMail_Click(object sender, EventArgs e)
        {
            TxtAdresseMail.Text = TxtAdresseMail.Text.Trim(); // On élimine les espaces de part et d'autre

            // Plusieurs approches possibles pour valider une adresse e-mail (à peu près) :
            // if (TxtAdresseMail.Text.Contains("@") && TxtAdresseMail.Text.Contains("."))
            // if (new EmailAddressAttribute().IsValid(TxtAdresseMail.Text))      
            if (Regex.IsMatch(TxtAdresseMail.Text, @"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$"))
            {
                if (CbInterdireDoublons.Checked)
                {
                    if (adressesMails.Contains(TxtAdresseMail.Text))
                    {
                        MessageBox.Show("Cette adresse est déjà présente dans la liste");
                    }
                    else
                    {
                        adressesMails.Add(TxtAdresseMail.Text);
                        TxtAdresseMail.Clear();
                    }
                }
                else
                {
                    adressesMails.Add(TxtAdresseMail.Text);
                    TxtAdresseMail.Clear();
                }
            }
        }

        private void TxtTrouverAdressesLesPlusCourtes_Click(object sender, EventArgs e)
        {
            List<string> adressesCourtes = new List<string>();
            int minLenght = 99999;
            for (int i = 0; i < adressesMails.Count; i++)
            {
                if (adressesMails[i].Length < minLenght)
                {
                    minLenght = adressesMails[i].Length;
                    adressesCourtes.Clear();
                }

                if (adressesMails[i].Length == minLenght)
                {
                    adressesCourtes.Add(adressesMails[i]);
                }
            }

            MessageBox.Show("Les adresses les plus courtes font " + minLenght.ToString() + " caractères :\r\n"
                + string.Join("\r\n", adressesCourtes));
        }

        private void TxtAdresseTerminantParFr_Click(object sender, EventArgs e)
        {
            string extension = ".fr";
            RechercheAdresseMail(extension);
        }

        private void TxtAdresseTerminantParCom_Click(object sender, EventArgs e)
        {
            string extension = ".com";
            RechercheAdresseMail(extension);
        }

        private void BtnRechercheDomaine_Click(object sender, EventArgs e)
        {
            RechercheAdresseMail(TxtRechercheDomaine.Text);
        }

        /// <summary>
        /// Méthode (fonction ou procédure) permettant de rechercher dans la fin d'une adresse mail.
        /// </summary>
        /// <param name="texteARechercher">Texte à rechercher</param>
        private void RechercheAdresseMail(string texteARechercher)
        {
            List<string> adresseARechercher = new List<string>();

            for (int i = 0; i < adressesMails.Count; i++)
            {
                if (adressesMails[i].EndsWith(texteARechercher))
                {
                    adresseARechercher.Add(adressesMails[i]);
                }
            }

            MessageBox.Show(string.Join("\r\n", adresseARechercher));
        }
    }
}
