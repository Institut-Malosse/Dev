﻿
namespace MinisExos
{
    partial class FrmPrincipale
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.LblTitre = new System.Windows.Forms.Label();
            this.BtnSurvol = new System.Windows.Forms.Button();
            this.BtnProcessusLourd = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.TxtChiffres = new System.Windows.Forms.TextBox();
            this.BtnMajuscules = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // LblTitre
            // 
            this.LblTitre.AutoSize = true;
            this.LblTitre.Font = new System.Drawing.Font("Segoe UI Black", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.LblTitre.ForeColor = System.Drawing.SystemColors.Highlight;
            this.LblTitre.Location = new System.Drawing.Point(13, 9);
            this.LblTitre.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LblTitre.Name = "LblTitre";
            this.LblTitre.Size = new System.Drawing.Size(126, 30);
            this.LblTitre.TabIndex = 12;
            this.LblTitre.Text = "Minis-exos";
            // 
            // BtnSurvol
            // 
            this.BtnSurvol.AutoSize = true;
            this.BtnSurvol.Location = new System.Drawing.Point(13, 42);
            this.BtnSurvol.Name = "BtnSurvol";
            this.BtnSurvol.Size = new System.Drawing.Size(335, 31);
            this.BtnSurvol.TabIndex = 13;
            this.BtnSurvol.Text = "Survoler ce bouton pour changer son texte";
            this.BtnSurvol.UseVisualStyleBackColor = true;
            this.BtnSurvol.Click += new System.EventHandler(this.BtnSurvol_Click);
            this.BtnSurvol.MouseEnter += new System.EventHandler(this.BtnSurvol_MouseEnter);
            this.BtnSurvol.MouseLeave += new System.EventHandler(this.BtnSurvol_MouseLeave);
            // 
            // BtnProcessusLourd
            // 
            this.BtnProcessusLourd.AutoSize = true;
            this.BtnProcessusLourd.Location = new System.Drawing.Point(13, 79);
            this.BtnProcessusLourd.Name = "BtnProcessusLourd";
            this.BtnProcessusLourd.Size = new System.Drawing.Size(513, 31);
            this.BtnProcessusLourd.TabIndex = 14;
            this.BtnProcessusLourd.Text = "Trouver le processus en cours d\'exécution ayant le plus de mémoire";
            this.BtnProcessusLourd.UseVisualStyleBackColor = true;
            this.BtnProcessusLourd.Click += new System.EventHandler(this.BtnProcessusLourd_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 119);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(304, 21);
            this.label1.TabIndex = 15;
            this.label1.Text = "Seuls des chiffres peuvent être saisis ici :";
            // 
            // TxtChiffres
            // 
            this.TxtChiffres.Location = new System.Drawing.Point(323, 116);
            this.TxtChiffres.Name = "TxtChiffres";
            this.TxtChiffres.Size = new System.Drawing.Size(129, 29);
            this.TxtChiffres.TabIndex = 16;
            this.TxtChiffres.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtChiffres_KeyPress);
            // 
            // BtnMajuscules
            // 
            this.BtnMajuscules.AutoSize = true;
            this.BtnMajuscules.Location = new System.Drawing.Point(13, 151);
            this.BtnMajuscules.Name = "BtnMajuscules";
            this.BtnMajuscules.Size = new System.Drawing.Size(417, 31);
            this.BtnMajuscules.TabIndex = 14;
            this.BtnMajuscules.Text = "Mettre en majuscule tous les boutons de cette fenêtre";
            this.BtnMajuscules.UseVisualStyleBackColor = true;
            this.BtnMajuscules.Click += new System.EventHandler(this.BtnMajuscules_Click);
            // 
            // FrmPrincipale
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 21F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(539, 196);
            this.Controls.Add(this.TxtChiffres);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.BtnMajuscules);
            this.Controls.Add(this.BtnProcessusLourd);
            this.Controls.Add(this.BtnSurvol);
            this.Controls.Add(this.LblTitre);
            this.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "FrmPrincipale";
            this.Text = "Minis-exos";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LblTitre;
        private System.Windows.Forms.Button BtnSurvol;
        private System.Windows.Forms.Button BtnProcessusLourd;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox TxtChiffres;
        private System.Windows.Forms.Button BtnMajuscules;
    }
}

