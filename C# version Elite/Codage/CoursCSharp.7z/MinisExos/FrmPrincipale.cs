﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MinisExos
{
    public partial class FrmPrincipale : Form
    {
        public FrmPrincipale()
        {
            InitializeComponent();
        }

        private void BtnSurvol_MouseEnter(object sender, EventArgs e)
        {
            BtnSurvol.Text = "Ne cliquez pas";
        }

        private void BtnSurvol_MouseLeave(object sender, EventArgs e)
        {
            BtnSurvol.Text = "Survoler ce bouton pour changer son texte";
        }

        private void BtnSurvol_Click(object sender, EventArgs e)
        {
            BtnSurvol.Enabled = false;
        }

        private void BtnProcessusLourd_Click(object sender, EventArgs e)
        {
            long chargeEnOctet = 0;
            Process processusLePlusLourd = new Process();

            // On parcoure tous les processus :
            foreach (Process processus in Process.GetProcesses())
            {
                // Si on trouve un processus plus lourd : on le mémorise
                if (processus.PrivateMemorySize64 > chargeEnOctet)
                {
                    processusLePlusLourd = processus;
                    chargeEnOctet = processusLePlusLourd.PrivateMemorySize64;
                }
            }

            long chargeEnMegaOctet = (processusLePlusLourd.PrivateMemorySize64 / 1024 / 1024);
            MessageBox.Show("Le processus le plus lourd en mémoire est : "
                + processusLePlusLourd.ProcessName
                + " (" + chargeEnMegaOctet.ToString() + " Mo)");

            // Pour obtenir la même chose que le gestionnaire des tâches (stackoverflow)
            PerformanceCounter infoProcess = new PerformanceCounter("Process", "Working Set - Private", processusLePlusLourd.ProcessName);
            double chargeMemoire = (double)infoProcess.RawValue / 1024.0 / 1024.0;
            MessageBox.Show("Le processus le plus lourd en mémoire est : " + processusLePlusLourd.ProcessName + " (" + chargeMemoire.ToString() + " Mo)");
        }

        private void TxtChiffres_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void BtnMajuscules_Click(object sender, EventArgs e)
        {
            // Première approche :
            // BtnProcessusLourd.Text = BtnProcessusLourd.Text.ToUpper();
            // BtnSurvol.Text = BtnSurvol.Text.ToUpper();
            // BtnMajuscules.Text = BtnMajuscules.Text.ToUpper();

            // Deuxième approche :
            foreach (Button btn in Controls.OfType<Button>())
            {
                btn.Text = btn.Text.ToUpper();
            }

            BtnMajuscules.Visible = false;
        }
    }
}
