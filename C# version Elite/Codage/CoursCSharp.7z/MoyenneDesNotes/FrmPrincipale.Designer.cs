﻿
namespace MoyenneDesNotes
{
    partial class FrmPrincipale
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.LblTitre = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.TxtNoteSurVingt = new System.Windows.Forms.TextBox();
            this.BtnAjouterAuTableau = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.LblNombreNoteTableau = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.BtnMoyenneTableau = new System.Windows.Forms.Button();
            this.BtnMedianeTableau = new System.Windows.Forms.Button();
            this.BtnClearTableau = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.LblNombreNoteCollection = new System.Windows.Forms.Label();
            this.BtnAjouterACollection = new System.Windows.Forms.Button();
            this.BtnMoyenneCollection = new System.Windows.Forms.Button();
            this.BtnMedianeCollection = new System.Windows.Forms.Button();
            this.BtnClearCollection = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // LblTitre
            // 
            this.LblTitre.AutoSize = true;
            this.LblTitre.Font = new System.Drawing.Font("Segoe UI Black", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.LblTitre.ForeColor = System.Drawing.SystemColors.Highlight;
            this.LblTitre.Location = new System.Drawing.Point(71, 9);
            this.LblTitre.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.LblTitre.Name = "LblTitre";
            this.LblTitre.Size = new System.Drawing.Size(213, 30);
            this.LblTitre.TabIndex = 9;
            this.LblTitre.Text = "Moyenne des notes";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(81, 76);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(197, 21);
            this.label1.TabIndex = 10;
            this.label1.Text = "Saisissez une note sur 20 :";
            // 
            // TxtNoteSurVingt
            // 
            this.TxtNoteSurVingt.Location = new System.Drawing.Point(121, 100);
            this.TxtNoteSurVingt.Name = "TxtNoteSurVingt";
            this.TxtNoteSurVingt.Size = new System.Drawing.Size(100, 29);
            this.TxtNoteSurVingt.TabIndex = 11;
            // 
            // BtnAjouterAuTableau
            // 
            this.BtnAjouterAuTableau.Location = new System.Drawing.Point(12, 145);
            this.BtnAjouterAuTableau.Name = "BtnAjouterAuTableau";
            this.BtnAjouterAuTableau.Size = new System.Drawing.Size(147, 58);
            this.BtnAjouterAuTableau.TabIndex = 12;
            this.BtnAjouterAuTableau.Text = "Ajouter au tableau";
            this.BtnAjouterAuTableau.UseVisualStyleBackColor = true;
            this.BtnAjouterAuTableau.Click += new System.EventHandler(this.BtnAjouterAuTableau_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 206);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(147, 21);
            this.label2.TabIndex = 10;
            this.label2.Text = "Nombre de notes :";
            // 
            // LblNombreNoteTableau
            // 
            this.LblNombreNoteTableau.AutoSize = true;
            this.LblNombreNoteTableau.Location = new System.Drawing.Point(75, 227);
            this.LblNombreNoteTableau.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LblNombreNoteTableau.Name = "LblNombreNoteTableau";
            this.LblNombreNoteTableau.Size = new System.Drawing.Size(19, 21);
            this.LblNombreNoteTableau.TabIndex = 10;
            this.LblNombreNoteTableau.Text = "0";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(54, 262);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(74, 21);
            this.label3.TabIndex = 10;
            this.label3.Text = "Obtenir :";
            // 
            // BtnMoyenneTableau
            // 
            this.BtnMoyenneTableau.Location = new System.Drawing.Point(12, 286);
            this.BtnMoyenneTableau.Name = "BtnMoyenneTableau";
            this.BtnMoyenneTableau.Size = new System.Drawing.Size(147, 31);
            this.BtnMoyenneTableau.TabIndex = 12;
            this.BtnMoyenneTableau.Text = "La moyenne";
            this.BtnMoyenneTableau.UseVisualStyleBackColor = true;
            this.BtnMoyenneTableau.Click += new System.EventHandler(this.BtnMoyenneTableau_Click);
            // 
            // BtnMedianeTableau
            // 
            this.BtnMedianeTableau.Location = new System.Drawing.Point(12, 323);
            this.BtnMedianeTableau.Name = "BtnMedianeTableau";
            this.BtnMedianeTableau.Size = new System.Drawing.Size(147, 31);
            this.BtnMedianeTableau.TabIndex = 12;
            this.BtnMedianeTableau.Text = "La médiane";
            this.BtnMedianeTableau.UseVisualStyleBackColor = true;
            this.BtnMedianeTableau.Click += new System.EventHandler(this.BtnMedianeTableau_Click);
            // 
            // BtnClearTableau
            // 
            this.BtnClearTableau.Location = new System.Drawing.Point(12, 376);
            this.BtnClearTableau.Name = "BtnClearTableau";
            this.BtnClearTableau.Size = new System.Drawing.Size(147, 31);
            this.BtnClearTableau.TabIndex = 12;
            this.BtnClearTableau.Text = "(clear)";
            this.BtnClearTableau.UseVisualStyleBackColor = true;
            this.BtnClearTableau.Click += new System.EventHandler(this.BtnClearTableau_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(186, 206);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(147, 21);
            this.label4.TabIndex = 10;
            this.label4.Text = "Nombre de notes :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(228, 262);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(74, 21);
            this.label5.TabIndex = 10;
            this.label5.Text = "Obtenir :";
            // 
            // LblNombreNoteCollection
            // 
            this.LblNombreNoteCollection.AutoSize = true;
            this.LblNombreNoteCollection.Location = new System.Drawing.Point(249, 227);
            this.LblNombreNoteCollection.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LblNombreNoteCollection.Name = "LblNombreNoteCollection";
            this.LblNombreNoteCollection.Size = new System.Drawing.Size(19, 21);
            this.LblNombreNoteCollection.TabIndex = 10;
            this.LblNombreNoteCollection.Text = "0";
            // 
            // BtnAjouterACollection
            // 
            this.BtnAjouterACollection.Location = new System.Drawing.Point(186, 145);
            this.BtnAjouterACollection.Name = "BtnAjouterACollection";
            this.BtnAjouterACollection.Size = new System.Drawing.Size(147, 58);
            this.BtnAjouterACollection.TabIndex = 12;
            this.BtnAjouterACollection.Text = "Ajouter à la collection";
            this.BtnAjouterACollection.UseVisualStyleBackColor = true;
            this.BtnAjouterACollection.Click += new System.EventHandler(this.BtnAjouterACollection_Click);
            // 
            // BtnMoyenneCollection
            // 
            this.BtnMoyenneCollection.Location = new System.Drawing.Point(186, 286);
            this.BtnMoyenneCollection.Name = "BtnMoyenneCollection";
            this.BtnMoyenneCollection.Size = new System.Drawing.Size(147, 31);
            this.BtnMoyenneCollection.TabIndex = 12;
            this.BtnMoyenneCollection.Text = "La moyenne";
            this.BtnMoyenneCollection.UseVisualStyleBackColor = true;
            this.BtnMoyenneCollection.Click += new System.EventHandler(this.BtnMoyenneCollection_Click);
            // 
            // BtnMedianeCollection
            // 
            this.BtnMedianeCollection.Location = new System.Drawing.Point(186, 323);
            this.BtnMedianeCollection.Name = "BtnMedianeCollection";
            this.BtnMedianeCollection.Size = new System.Drawing.Size(147, 31);
            this.BtnMedianeCollection.TabIndex = 12;
            this.BtnMedianeCollection.Text = "La médiane";
            this.BtnMedianeCollection.UseVisualStyleBackColor = true;
            this.BtnMedianeCollection.Click += new System.EventHandler(this.BtnMedianeCollection_Click);
            // 
            // BtnClearCollection
            // 
            this.BtnClearCollection.Location = new System.Drawing.Point(186, 376);
            this.BtnClearCollection.Name = "BtnClearCollection";
            this.BtnClearCollection.Size = new System.Drawing.Size(147, 31);
            this.BtnClearCollection.TabIndex = 12;
            this.BtnClearCollection.Text = "(clear)";
            this.BtnClearCollection.UseVisualStyleBackColor = true;
            this.BtnClearCollection.Click += new System.EventHandler(this.BtnClearCollection_Click);
            // 
            // FrmPrincipale
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 21F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(349, 426);
            this.Controls.Add(this.BtnClearCollection);
            this.Controls.Add(this.BtnClearTableau);
            this.Controls.Add(this.BtnMedianeCollection);
            this.Controls.Add(this.BtnMedianeTableau);
            this.Controls.Add(this.BtnMoyenneCollection);
            this.Controls.Add(this.BtnMoyenneTableau);
            this.Controls.Add(this.BtnAjouterACollection);
            this.Controls.Add(this.BtnAjouterAuTableau);
            this.Controls.Add(this.LblNombreNoteCollection);
            this.Controls.Add(this.TxtNoteSurVingt);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.LblNombreNoteTableau);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.LblTitre);
            this.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "FrmPrincipale";
            this.Text = "Moyenne des notes";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LblTitre;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox TxtNoteSurVingt;
        private System.Windows.Forms.Button BtnAjouterAuTableau;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label LblNombreNoteTableau;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button BtnMoyenneTableau;
        private System.Windows.Forms.Button BtnMedianeTableau;
        private System.Windows.Forms.Button BtnClearTableau;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label LblNombreNoteCollection;
        private System.Windows.Forms.Button BtnAjouterACollection;
        private System.Windows.Forms.Button BtnMoyenneCollection;
        private System.Windows.Forms.Button BtnMedianeCollection;
        private System.Windows.Forms.Button BtnClearCollection;
    }
}

