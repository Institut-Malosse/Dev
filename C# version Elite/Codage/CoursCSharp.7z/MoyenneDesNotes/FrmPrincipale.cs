﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MoyenneDesNotes
{
    public partial class FrmPrincipale : Form
    {
        public FrmPrincipale()
        {
            InitializeComponent();
        }

        decimal[] tableauNotes = new decimal[0];
        List<decimal> collectionNotes = new List<decimal>();

        private void BtnAjouterAuTableau_Click(object sender, EventArgs e)
        {
            if (decimal.TryParse(TxtNoteSurVingt.Text, out decimal note) && note >= 0 && note <= 20)
            {
                Array.Resize(ref tableauNotes, tableauNotes.Length + 1);
                tableauNotes[tableauNotes.Length - 1] = note;
                LblNombreNoteTableau.Text = tableauNotes.Length.ToString();
                TxtNoteSurVingt.Clear();
            }
            else
            {
                MessageBox.Show("Le note doit être un nombre entier compris entre 0 et 20");
            }
        }

        private void BtnMoyenneTableau_Click(object sender, EventArgs e)
        {
            decimal total = 0;
            decimal moyenne = 0m;

            for (int i = 0; i < tableauNotes.Length; i++)
            {
                total += tableauNotes[i];
            }
            moyenne = total / tableauNotes.Length;
            moyenne = Math.Round(moyenne, 1);

            MessageBox.Show("La moyenne des notes est de " + moyenne.ToString() + "/20.");
        }

        private void BtnMedianeTableau_Click(object sender, EventArgs e)
        {
            Array.Sort(tableauNotes);

            decimal mediane = 0m;
            if (tableauNotes.Length % 2 == 0)
            {
                int bigIndex = tableauNotes.Length / 2;
                decimal medianeSup = tableauNotes[bigIndex];
                decimal medianeInf = tableauNotes[bigIndex - 1];
                mediane = (medianeSup + medianeInf) / 2m;
            }
            else
            {
                int index = (tableauNotes.Length - 1) / 2;
                mediane = tableauNotes[index];
            }

            MessageBox.Show("La médiane des notes est de " + mediane.ToString() + "/20.");
        }

        private void BtnClearTableau_Click(object sender, EventArgs e)
        {
            Array.Clear(tableauNotes, 0, tableauNotes.Length);
            Array.Resize(ref tableauNotes, 0);
            LblNombreNoteTableau.Text = tableauNotes.Length.ToString();
        }

        private void BtnAjouterACollection_Click(object sender, EventArgs e)
        {
            if (decimal.TryParse(TxtNoteSurVingt.Text, out decimal note) && note >= 0 && note <= 20)
            {
                collectionNotes.Add(note); // Ajoute une note dans la collection
                LblNombreNoteCollection.Text = collectionNotes.Count.ToString();
                TxtNoteSurVingt.Clear();
            }
            else
            {
                MessageBox.Show("Le note doit être un nombre entier compris entre 0 et 20");
            }
        }

        private void BtnMoyenneCollection_Click(object sender, EventArgs e)
        {
            decimal moyenne = collectionNotes.Average(); // J'utilise une fonction du Framework pour calculer la moyenne

            MessageBox.Show("La moyenne des notes est de " + moyenne.ToString() + "/20.");
        }

        private void BtnMedianeCollection_Click(object sender, EventArgs e)
        {
            collectionNotes.Sort();

            decimal mediane = 0m;
            if (collectionNotes.Count % 2 == 0)
            {
                int bigIndex = collectionNotes.Count / 2;
                decimal medianeSup = collectionNotes[bigIndex];
                decimal medianeInf = collectionNotes[bigIndex - 1];
                mediane = (medianeSup + medianeInf) / 2m;
            }
            else
            {
                int index = (collectionNotes.Count - 1) / 2;
                mediane = collectionNotes[index];
            }

            MessageBox.Show("La médiane des notes est de " + mediane.ToString() + "/20.");
        }

        private void BtnClearCollection_Click(object sender, EventArgs e)
        {
            collectionNotes.Clear();
            LblNombreNoteCollection.Text = collectionNotes.Count.ToString();
        }
    }
}
