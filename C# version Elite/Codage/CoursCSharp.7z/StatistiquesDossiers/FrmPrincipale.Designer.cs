﻿
namespace StatistiquesDossiers
{
    partial class FrmPrincipale
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.LblDossier = new System.Windows.Forms.Label();
            this.TxtDossier = new System.Windows.Forms.TextBox();
            this.LblTitre = new System.Windows.Forms.Label();
            this.BtnDossierExiste = new System.Windows.Forms.Button();
            this.BtnNombreFichierDansDossier = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // LblDossier
            // 
            this.LblDossier.AutoSize = true;
            this.LblDossier.Location = new System.Drawing.Point(13, 59);
            this.LblDossier.Name = "LblDossier";
            this.LblDossier.Size = new System.Drawing.Size(72, 21);
            this.LblDossier.TabIndex = 9;
            this.LblDossier.Text = "Dossier :";
            // 
            // TxtDossier
            // 
            this.TxtDossier.Location = new System.Drawing.Point(91, 56);
            this.TxtDossier.Name = "TxtDossier";
            this.TxtDossier.Size = new System.Drawing.Size(471, 29);
            this.TxtDossier.TabIndex = 8;
            // 
            // LblTitre
            // 
            this.LblTitre.AutoSize = true;
            this.LblTitre.Font = new System.Drawing.Font("Segoe UI Black", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.LblTitre.ForeColor = System.Drawing.SystemColors.Highlight;
            this.LblTitre.Location = new System.Drawing.Point(13, 9);
            this.LblTitre.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LblTitre.Name = "LblTitre";
            this.LblTitre.Size = new System.Drawing.Size(254, 30);
            this.LblTitre.TabIndex = 7;
            this.LblTitre.Text = "Statistiques de dossiers";
            // 
            // BtnDossierExiste
            // 
            this.BtnDossierExiste.AutoSize = true;
            this.BtnDossierExiste.Location = new System.Drawing.Point(91, 91);
            this.BtnDossierExiste.Name = "BtnDossierExiste";
            this.BtnDossierExiste.Size = new System.Drawing.Size(177, 31);
            this.BtnDossierExiste.TabIndex = 10;
            this.BtnDossierExiste.Text = "Le dossier existe-t-il ?";
            this.BtnDossierExiste.UseVisualStyleBackColor = true;
            this.BtnDossierExiste.Click += new System.EventHandler(this.BtnDossierExiste_Click);
            // 
            // BtnNombreFichierDansDossier
            // 
            this.BtnNombreFichierDansDossier.AutoSize = true;
            this.BtnNombreFichierDansDossier.Location = new System.Drawing.Point(274, 91);
            this.BtnNombreFichierDansDossier.Name = "BtnNombreFichierDansDossier";
            this.BtnNombreFichierDansDossier.Size = new System.Drawing.Size(288, 31);
            this.BtnNombreFichierDansDossier.TabIndex = 10;
            this.BtnNombreFichierDansDossier.Text = "Nombre de fichiers dans ce dossier ?";
            this.BtnNombreFichierDansDossier.UseVisualStyleBackColor = true;
            this.BtnNombreFichierDansDossier.Click += new System.EventHandler(this.BtnNombreFichierDansDossier_Click);
            // 
            // FrmPrincipale
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 21F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(573, 133);
            this.Controls.Add(this.BtnNombreFichierDansDossier);
            this.Controls.Add(this.BtnDossierExiste);
            this.Controls.Add(this.LblDossier);
            this.Controls.Add(this.TxtDossier);
            this.Controls.Add(this.LblTitre);
            this.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "FrmPrincipale";
            this.Text = "Statistiques de dossiers";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LblDossier;
        private System.Windows.Forms.TextBox TxtDossier;
        private System.Windows.Forms.Label LblTitre;
        private System.Windows.Forms.Button BtnDossierExiste;
        private System.Windows.Forms.Button BtnNombreFichierDansDossier;
    }
}

