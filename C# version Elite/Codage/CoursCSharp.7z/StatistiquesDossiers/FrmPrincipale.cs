﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StatistiquesDossiers
{
    public partial class FrmPrincipale : Form
    {
        public FrmPrincipale()
        {
            InitializeComponent();
        }

        private void BtnDossierExiste_Click(object sender, EventArgs e)
        {
            // On vérifie l'existence du répertoire :
            if (Directory.Exists(TxtDossier.Text)) // Cette ligne de code utilise la librairie System.IO
            {
                // Oui : il existe
                MessageBox.Show("Le répertoire existe !");
                BtnNombreFichierDansDossier.Enabled = true; // On débloque le bouton de comptage
            }
            else
            {
                // Non : il n'existe pas
                MessageBox.Show("Le répertoire n'existe pas...");
                BtnNombreFichierDansDossier.Enabled = false; // On bloque le bouton de comptage
            }
        }

        private void BtnNombreFichierDansDossier_Click(object sender, EventArgs e)
        {
            // On compte le nombre de fichier dans le répertoire :
            int nombre = Directory.GetFiles(TxtDossier.Text).Length; // Cette ligne de code utilise la librairie System.IO
            MessageBox.Show("Il y a " + nombre.ToString() + " fichiers"); // On affiche le résultat
        }
    }
}
