﻿
namespace StatistiquesDossiers2
{
    partial class FrmPrincipale
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.BtnNombreFichierDansDossier = new System.Windows.Forms.Button();
            this.BtnDossierExiste = new System.Windows.Forms.Button();
            this.LblDossier = new System.Windows.Forms.Label();
            this.TxtDossier = new System.Windows.Forms.TextBox();
            this.LblTitre = new System.Windows.Forms.Label();
            this.BtnListeFichiersAz = new System.Windows.Forms.Button();
            this.BtnListeFichiersZa = new System.Windows.Forms.Button();
            this.BtnCompterNombreFichierAyantExtension = new System.Windows.Forms.Button();
            this.TxtExtension = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // BtnNombreFichierDansDossier
            // 
            this.BtnNombreFichierDansDossier.AutoSize = true;
            this.BtnNombreFichierDansDossier.Enabled = false;
            this.BtnNombreFichierDansDossier.Location = new System.Drawing.Point(274, 91);
            this.BtnNombreFichierDansDossier.Name = "BtnNombreFichierDansDossier";
            this.BtnNombreFichierDansDossier.Size = new System.Drawing.Size(288, 31);
            this.BtnNombreFichierDansDossier.TabIndex = 14;
            this.BtnNombreFichierDansDossier.Text = "Nombre de fichiers dans ce dossier ?";
            this.BtnNombreFichierDansDossier.UseVisualStyleBackColor = true;
            this.BtnNombreFichierDansDossier.Click += new System.EventHandler(this.BtnNombreFichierDansDossier_Click);
            // 
            // BtnDossierExiste
            // 
            this.BtnDossierExiste.AutoSize = true;
            this.BtnDossierExiste.Location = new System.Drawing.Point(91, 91);
            this.BtnDossierExiste.Name = "BtnDossierExiste";
            this.BtnDossierExiste.Size = new System.Drawing.Size(177, 31);
            this.BtnDossierExiste.TabIndex = 15;
            this.BtnDossierExiste.Text = "Le dossier existe-t-il ?";
            this.BtnDossierExiste.UseVisualStyleBackColor = true;
            this.BtnDossierExiste.Click += new System.EventHandler(this.BtnDossierExiste_Click);
            // 
            // LblDossier
            // 
            this.LblDossier.AutoSize = true;
            this.LblDossier.Location = new System.Drawing.Point(13, 59);
            this.LblDossier.Name = "LblDossier";
            this.LblDossier.Size = new System.Drawing.Size(72, 21);
            this.LblDossier.TabIndex = 13;
            this.LblDossier.Text = "Dossier :";
            // 
            // TxtDossier
            // 
            this.TxtDossier.Location = new System.Drawing.Point(91, 56);
            this.TxtDossier.Name = "TxtDossier";
            this.TxtDossier.Size = new System.Drawing.Size(471, 29);
            this.TxtDossier.TabIndex = 12;
            this.TxtDossier.TextChanged += new System.EventHandler(this.TxtDossier_TextChanged);
            // 
            // LblTitre
            // 
            this.LblTitre.AutoSize = true;
            this.LblTitre.Font = new System.Drawing.Font("Segoe UI Black", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.LblTitre.ForeColor = System.Drawing.SystemColors.Highlight;
            this.LblTitre.Location = new System.Drawing.Point(13, 9);
            this.LblTitre.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LblTitre.Name = "LblTitre";
            this.LblTitre.Size = new System.Drawing.Size(273, 30);
            this.LblTitre.TabIndex = 11;
            this.LblTitre.Text = "Statistiques de dossiers 2";
            // 
            // BtnListeFichiersAz
            // 
            this.BtnListeFichiersAz.AutoSize = true;
            this.BtnListeFichiersAz.Enabled = false;
            this.BtnListeFichiersAz.Location = new System.Drawing.Point(91, 128);
            this.BtnListeFichiersAz.Name = "BtnListeFichiersAz";
            this.BtnListeFichiersAz.Size = new System.Drawing.Size(250, 31);
            this.BtnListeFichiersAz.TabIndex = 15;
            this.BtnListeFichiersAz.Text = "Liste des fichiers (triés de A à Z)";
            this.BtnListeFichiersAz.UseVisualStyleBackColor = true;
            this.BtnListeFichiersAz.Click += new System.EventHandler(this.BtnListeFichiersAz_Click);
            // 
            // BtnListeFichiersZa
            // 
            this.BtnListeFichiersZa.AutoSize = true;
            this.BtnListeFichiersZa.Enabled = false;
            this.BtnListeFichiersZa.Location = new System.Drawing.Point(347, 128);
            this.BtnListeFichiersZa.Name = "BtnListeFichiersZa";
            this.BtnListeFichiersZa.Size = new System.Drawing.Size(214, 31);
            this.BtnListeFichiersZa.TabIndex = 15;
            this.BtnListeFichiersZa.Text = "Liste des fichiers (de Z à A)";
            this.BtnListeFichiersZa.UseVisualStyleBackColor = true;
            this.BtnListeFichiersZa.Click += new System.EventHandler(this.BtnListeFichiersZa_Click);
            // 
            // BtnCompterNombreFichierAyantExtension
            // 
            this.BtnCompterNombreFichierAyantExtension.AutoSize = true;
            this.BtnCompterNombreFichierAyantExtension.Enabled = false;
            this.BtnCompterNombreFichierAyantExtension.Location = new System.Drawing.Point(91, 165);
            this.BtnCompterNombreFichierAyantExtension.Name = "BtnCompterNombreFichierAyantExtension";
            this.BtnCompterNombreFichierAyantExtension.Size = new System.Drawing.Size(412, 31);
            this.BtnCompterNombreFichierAyantExtension.TabIndex = 15;
            this.BtnCompterNombreFichierAyantExtension.Text = "Compter le nombre de fichiers ayant cette extension :";
            this.BtnCompterNombreFichierAyantExtension.UseVisualStyleBackColor = true;
            this.BtnCompterNombreFichierAyantExtension.Click += new System.EventHandler(this.BtnCompterNombreFichierAyantExtension_Click);
            // 
            // TxtExtension
            // 
            this.TxtExtension.Enabled = false;
            this.TxtExtension.Location = new System.Drawing.Point(508, 166);
            this.TxtExtension.Name = "TxtExtension";
            this.TxtExtension.Size = new System.Drawing.Size(53, 29);
            this.TxtExtension.TabIndex = 12;
            // 
            // FrmPrincipale
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 21F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(575, 211);
            this.Controls.Add(this.BtnNombreFichierDansDossier);
            this.Controls.Add(this.BtnListeFichiersZa);
            this.Controls.Add(this.BtnCompterNombreFichierAyantExtension);
            this.Controls.Add(this.BtnListeFichiersAz);
            this.Controls.Add(this.BtnDossierExiste);
            this.Controls.Add(this.LblDossier);
            this.Controls.Add(this.TxtExtension);
            this.Controls.Add(this.TxtDossier);
            this.Controls.Add(this.LblTitre);
            this.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "FrmPrincipale";
            this.Text = "Statistiques de dossiers 2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BtnNombreFichierDansDossier;
        private System.Windows.Forms.Button BtnDossierExiste;
        private System.Windows.Forms.Label LblDossier;
        private System.Windows.Forms.TextBox TxtDossier;
        private System.Windows.Forms.Label LblTitre;
        private System.Windows.Forms.Button BtnListeFichiersAz;
        private System.Windows.Forms.Button BtnListeFichiersZa;
        private System.Windows.Forms.Button BtnCompterNombreFichierAyantExtension;
        private System.Windows.Forms.TextBox TxtExtension;
    }
}

