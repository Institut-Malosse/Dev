﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StatistiquesDossiers2
{
    public partial class FrmPrincipale : Form
    {
        public FrmPrincipale()
        {
            InitializeComponent();
        }

        private void TxtDossier_TextChanged(object sender, EventArgs e)
        {
            if (Directory.Exists(TxtDossier.Text)) // Cette ligne de code utilise la librairie System.IO
            {
                // Oui : il existe : on débloque les boutons
                BtnNombreFichierDansDossier.Enabled = true;
                BtnListeFichiersAz.Enabled = true;
                BtnListeFichiersZa.Enabled = true;
                BtnCompterNombreFichierAyantExtension.Enabled = true;
                TxtExtension.Enabled = true;
            }
            else
            {
                // Non : il n'existe pas : on bloque les boutons
                BtnNombreFichierDansDossier.Enabled = false;
                BtnListeFichiersAz.Enabled = false;
                BtnListeFichiersZa.Enabled = false;
                BtnCompterNombreFichierAyantExtension.Enabled = false;
                TxtExtension.Enabled = false;
            }
        }

        private void BtnDossierExiste_Click(object sender, EventArgs e)
        {
            // On vérifie l'existence du répertoire :
            if (Directory.Exists(TxtDossier.Text)) // Cette ligne de code utilise la librairie System.IO
            {
                // Oui : il existe
                MessageBox.Show("Le répertoire existe !");
            }
            else
            {
                // Non : il n'existe pas
                MessageBox.Show("Le répertoire n'existe pas...");
            }
        }

        private void BtnNombreFichierDansDossier_Click(object sender, EventArgs e)
        {
            // On compte le nombre de fichier dans le répertoire :
            int nombre = Directory.GetFiles(TxtDossier.Text).Length; // Cette ligne de code utilise la librairie System.IO
            MessageBox.Show("Il y a " + nombre.ToString() + " fichiers"); // On affiche le résultat
        }

        private void BtnListeFichiersAz_Click(object sender, EventArgs e)
        {
            string[] tableauFichier = Directory.GetFiles(TxtDossier.Text);
            Array.Sort(tableauFichier);
            MessageBox.Show(string.Join("\r\n", tableauFichier));
        }

        private void BtnListeFichiersZa_Click(object sender, EventArgs e)
        {
            string[] tableauFichier = Directory.GetFiles(TxtDossier.Text);
            List<string> listeFichier = tableauFichier.ToList();
            listeFichier.Sort();
            listeFichier.Reverse();
            MessageBox.Show(string.Join("\r\n", listeFichier));
        }

        private void BtnCompterNombreFichierAyantExtension_Click(object sender, EventArgs e)
        {
            string[] tableauFichier = Directory.GetFiles(TxtDossier.Text);
            int nombreTrouve = 0;
            for (int i = 0; i < tableauFichier.Length; i++)
            {
                if (tableauFichier[i].EndsWith(TxtExtension.Text))
                {
                    nombreTrouve++;
                }
            }

            MessageBox.Show(nombreTrouve.ToString() + " fichier(s) correspondant(s) à l'extension " + TxtExtension.Text);
        }
    }
}
